
/*if EC2 Instance changed, then update the IP address
for EX: http://3.237.81.127:7070/meeting-checklist ==== http://CHECKLIST_SERVICE/meeting-checklist*/
export const CHECKLIST_SERVICE =  "34.232.77.112:7070";
export const QUESTIONNAIRE_SERVICE= "3.215.179.38:7071";

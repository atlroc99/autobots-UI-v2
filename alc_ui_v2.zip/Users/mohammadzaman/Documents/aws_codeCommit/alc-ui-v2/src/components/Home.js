import React from 'react';
import logo from '../image/alc-logo.png';

const Home = () => {
  return (
    <div style={{height:'800px'}}>
    <img className="logoHome"  src={logo} alt="logo"></img>
    </div>
  )
}

export default Home

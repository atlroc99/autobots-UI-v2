      npm install

      npm start

build docker image :

            docker-compose up

CheckList Component:

Post URL : http://localhost:7070/add-meeting

Get URL : http://localhost:7070/meeting-checklist

Put URL :http://localhost:7070/edit-checklist/{id}

delete URL: http://localhost:7070/delete-checklist/{id}

Questionnare Componet:

Post Url:http://localhost:7071/add-questionnare

Get Url:http://localhost:7071/questionnare-list

Put Url:http://localhost:7071/edit-questionnare/{id}

Delete Url:http://localhost:7071/edit-questionnare/{id}

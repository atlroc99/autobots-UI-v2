import React from 'react';

const Footer = () => {
    return(
        <footer className = "footerBox">
            <br></br>
            <br></br>
            <p className="footerTag" style={{textAlign:'center'}}>A Carrier Company &#169; Carrier 2020 All rights reserved.</p>
        </footer>
    );
}
export default Footer;